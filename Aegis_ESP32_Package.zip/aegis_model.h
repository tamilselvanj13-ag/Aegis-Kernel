/**
 * ============================================================================
 * AEGIS_MODEL.H - UNIFIED TINYML & CONTINUAL LEARNING INFERENCE ENGINE
 * ============================================================================
 * Supports both:
 *  1. Microsecond Static Decision Tree (predict_aegis_8d) - < 1.5 us
 *  2. Continual Learning & Experience Consolidation Engine (predict_continual,
 *     consolidate_experience_batch) with Bounded Replay Buffer & Flash NVS
 * ============================================================================
 */

#ifndef AEGIS_MODEL_H
#define AEGIS_MODEL_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

#define EXPERIENCE_BUFFER_CAPACITY 16  // Bounded circular buffer size

/**
 * @brief Aegis Threat Classification Levels
 */
typedef enum {
    AEGIS_LEVEL_SAFE       = 0,
    AEGIS_LEVEL_SUSPICIOUS = 1,
    AEGIS_LEVEL_MALICIOUS  = 2,
    AEGIS_LEVEL_CRITICAL   = 3
} AegisThreatLevel;

/**
 * @brief 8-Dimensional Process Telemetry Feature Vector
 */
typedef struct {
    int   is_temp;         // 1 if executing from /tmp, /var/tmp, /dev/shm
    int   arg_len;         // Length of commandline / argument string
    float entropy;         // Shannon entropy of process command line (0.0 to 8.0)
    int   is_root;         // 1 if running as root (UID == 0)
    int   web_parent;      // 1 if parent process is a web server (nginx, apache2)
    int   is_parent_dead;  // 1 if parent PID is dead / orphaned
    int   memfd;           // 1 if anonymous fileless execution (memfd:name)
    int   ld_preload;      // 1 if shell spawner / LD_PRELOAD injection detected
} ProcessTelemetry;

/**
 * @brief Compressed Experience Sample in Replay Buffer
 */
typedef struct {
    ProcessTelemetry vec;
    float target_label;    // 0.0 (SAFE) to 1.0 (CRITICAL)
    uint32_t timestamp_ms; // Sample acquisition time
} ExperienceSample;

/**
 * @brief Continual Adaptive Model Parameters & Compressed Statistical Baselines
 */
typedef struct {
    float weights[8];          // Dynamic feature weights
    float momentum[8];         // Momentum gradient history
    float bias;                // Dynamic classification bias
    float bias_momentum;
    
    // Compressed Running Feature Statistics (Welford's Algorithm)
    float feature_mean[8];     // Running mean for all 8 features
    float feature_var[8];      // Running variance for all 8 features
    
    float entropy_baseline;    // Running EMA of normal entropy
    float len_baseline;        // Running EMA of normal argument length
    float learning_rate;       // Base learning rate (0.04)
    float momentum_factor;     // Momentum coefficient (0.85)
    
    uint32_t total_consolidations; // Number of compression/flush cycles completed
    uint32_t total_samples_learned;// Lifetime samples absorbed into weights
} ContinualModelWeights;

// Factory default initialized weights
static const ContinualModelWeights DEFAULT_CONTINUAL_MODEL = {
    .weights = { 0.85f, 0.015f, 0.95f, 0.65f, 1.40f, 0.75f, 2.10f, 1.25f },
    .momentum = { 0 },
    .bias = -4.50f,
    .bias_momentum = 0.0f,
    .feature_mean = { 0.05f, 35.0f, 3.15f, 0.15f, 0.02f, 0.05f, 0.01f, 0.02f },
    .feature_var  = { 0.05f, 400.0f, 0.15f, 0.12f, 0.02f, 0.05f, 0.01f, 0.02f },
    .entropy_baseline = 3.15f,
    .len_baseline = 35.0f,
    .learning_rate = 0.04f,
    .momentum_factor = 0.85f,
    .total_consolidations = 0,
    .total_samples_learned = 0
};

// Also provide alias for backward compatibility
typedef ContinualModelWeights AdaptiveModelWeights;
#define DEFAULT_ADAPTIVE_MODEL DEFAULT_CONTINUAL_MODEL

/**
 * @brief Sigmoid activation
 */
static inline float sigmoid_f(float z) {
    return 1.0f / (1.0f + expf(-z));
}

/**
 * @brief High-Speed Static Decision Tree Predictor (< 1.5 us)
 */
static inline AegisThreatLevel predict_aegis_8d(const ProcessTelemetry *v) {
    if (!v) return AEGIS_LEVEL_CRITICAL;

    if (v->entropy <= 3.6989f) {
        if (v->entropy <= 3.4997f) {
            return (AegisThreatLevel)0; // SAFE
        } else {
            if (v->arg_len <= 64) {
                if (v->is_temp <= 0) {
                    return (AegisThreatLevel)0; // SAFE
                } else {
                    return (AegisThreatLevel)1; // SUSPICIOUS
                }
            } else {
                if (v->is_temp <= 0) {
                    if (v->arg_len <= 87) {
                        return (AegisThreatLevel)0; // SAFE
                    } else {
                        return (AegisThreatLevel)1; // SUSPICIOUS
                    }
                } else {
                    return (AegisThreatLevel)1; // SUSPICIOUS
                }
            }
        }
    } else {
        if (v->memfd <= 0) {
            if (v->arg_len <= 110) {
                if (v->web_parent <= 0) {
                    if (v->entropy <= 4.7150f) {
                        return (AegisThreatLevel)1; // SUSPICIOUS
                    } else {
                        return (AegisThreatLevel)2; // MALICIOUS
                    }
                } else {
                    return (AegisThreatLevel)2; // MALICIOUS
                }
            } else {
                if (v->is_root <= 0) {
                    return (AegisThreatLevel)2; // MALICIOUS
                } else {
                    return (AegisThreatLevel)3; // CRITICAL
                }
            }
        } else {
            if (v->is_root <= 0) {
                return (AegisThreatLevel)2; // MALICIOUS
            } else {
                return (AegisThreatLevel)3; // CRITICAL
            }
        }
    }
}

/**
 * @brief Continual Adaptive Online Predictor
 * 
 * Computes: z = bias + SUM( w_i * x_i )
 */
static inline AegisThreatLevel predict_continual(const ProcessTelemetry *v, 
                                                const ContinualModelWeights *model,
                                                float *out_prob) {
    if (!v || !model) return AEGIS_LEVEL_CRITICAL;

    float norm_temp    = (float)v->is_temp;
    float norm_len     = (float)v->arg_len / 50.0f;
    float norm_entropy = v->entropy - model->entropy_baseline;
    float norm_root    = (float)v->is_root;
    float norm_web     = (float)v->web_parent;
    float norm_dead    = (float)v->is_parent_dead;
    float norm_memfd   = (float)v->memfd;
    float norm_ld      = (float)v->ld_preload;

    float z = model->bias +
              model->weights[0] * norm_temp +
              model->weights[1] * norm_len +
              model->weights[2] * norm_entropy +
              model->weights[3] * norm_root +
              model->weights[4] * norm_web +
              model->weights[5] * norm_dead +
              model->weights[6] * norm_memfd +
              model->weights[7] * norm_ld;

    float prob = sigmoid_f(z);
    if (out_prob) *out_prob = prob;

    // Hard heuristic overrides for severe intrusion primitives
    if (v->memfd > 0 && v->is_root > 0) return AEGIS_LEVEL_CRITICAL;
    if (v->web_parent > 0 && v->ld_preload > 0) return AEGIS_LEVEL_CRITICAL;

    if (prob > 0.85f) return AEGIS_LEVEL_CRITICAL;
    if (prob > 0.65f) return AEGIS_LEVEL_MALICIOUS;
    if (prob > 0.40f) return AEGIS_LEVEL_SUSPICIOUS;
    return AEGIS_LEVEL_SAFE;
}

// Alias for backward compatibility
#define predict_adaptive predict_continual

/**
 * @brief Consolidate Experience Buffer into Persistent Model Weights
 * 
 * Bakes the batch experience into the weights using Momentum SGD,
 * updates running feature moments, and purges the buffer.
 */
static inline void consolidate_experience_batch(ContinualModelWeights *model,
                                                const ExperienceSample *buffer,
                                                int count) {
    if (!model || !buffer || count <= 0) return;

    float eta = model->learning_rate;
    float gamma = model->momentum_factor;

    for (int s = 0; s < count; s++) {
        const ProcessTelemetry *v = &buffer[s].vec;
        float target = buffer[s].target_label;

        float prob = 0.0f;
        predict_continual(v, model, &prob);
        float error = target - prob;

        float x[8];
        x[0] = (float)v->is_temp;
        x[1] = (float)v->arg_len / 50.0f;
        x[2] = v->entropy - model->entropy_baseline;
        x[3] = (float)v->is_root;
        x[4] = (float)v->web_parent;
        x[5] = (float)v->is_parent_dead;
        x[6] = (float)v->memfd;
        x[7] = (float)v->ld_preload;

        // Momentum SGD weight updates
        for (int i = 0; i < 8; i++) {
            float grad = error * x[i];
            model->momentum[i] = gamma * model->momentum[i] + (1.0f - gamma) * grad;
            model->weights[i] += eta * model->momentum[i];

            // Weight clipping to prevent divergence
            if (model->weights[i] < -6.0f) model->weights[i] = -6.0f;
            if (model->weights[i] > 12.0f) model->weights[i] = 12.0f;
        }

        model->bias_momentum = gamma * model->bias_momentum + (1.0f - gamma) * error;
        model->bias += eta * model->bias_momentum;

        // Update Welford's running statistics for normal baselines
        if (target <= 0.15f) {
            float alpha = 0.05f;
            model->entropy_baseline = (1.0f - alpha) * model->entropy_baseline + alpha * v->entropy;
            model->len_baseline = (1.0f - alpha) * model->len_baseline + alpha * (float)v->arg_len;
        }

        model->total_samples_learned++;
    }

    model->total_consolidations++;
}

/**
 * @brief Single-Sample Online Adaptation Step
 */
static inline void update_model_online(ContinualModelWeights *model,
                                       const ProcessTelemetry *v,
                                       float target_label) {
    if (!model || !v) return;
    ExperienceSample sample;
    sample.vec = *v;
    sample.target_label = target_label;
    sample.timestamp_ms = 0;
    consolidate_experience_batch(model, &sample, 1);
}

/**
 * @brief Continuous Threat Severity Score (0 - 100)
 */
static inline int compute_threat_score(const ProcessTelemetry *v) {
    if (!v) return 100;
    int score = 5;
    if (v->memfd > 0)        score += 40;
    if (v->web_parent > 0)   score += 35;
    if (v->is_temp > 0)      score += 20;
    if (v->ld_preload > 0)   score += 20;
    if (v->is_parent_dead > 0) score += 10;
    if (v->is_root > 0)      score += 10;

    if (v->entropy > 4.5f) {
        score += 30;
    } else if (v->entropy > 3.8f) {
        score += (int)((v->entropy - 3.8f) * 40.0f);
    }

    if (v->arg_len > 250) {
        score += 15;
    } else if (v->arg_len > 80) {
        score += (v->arg_len - 80) / 15;
    }

    if (score > 100) score = 100;
    if (score < 0)   score = 0;
    return score;
}

/**
 * @brief Return plain text label for threat level
 */
static inline const char* get_level_str(AegisThreatLevel level) {
    switch (level) {
        case AEGIS_LEVEL_SAFE:       return "SAFE";
        case AEGIS_LEVEL_SUSPICIOUS: return "SUSPICIOUS";
        case AEGIS_LEVEL_MALICIOUS:  return "MALICIOUS";
        case AEGIS_LEVEL_CRITICAL:   return "CRITICAL";
        default:                     return "UNKNOWN";
    }
}

/**
 * @brief Return ANSI colored label for terminal display
 */
static inline const char* get_verdict_ansi(AegisThreatLevel level) {
    switch (level) {
        case AEGIS_LEVEL_SAFE:       return "\033[32m[SAFE]\033[0m";
        case AEGIS_LEVEL_SUSPICIOUS: return "\033[33m[SUSPICIOUS]\033[0m";
        case AEGIS_LEVEL_MALICIOUS:  return "\033[31m[MALICIOUS]\033[0m";
        case AEGIS_LEVEL_CRITICAL:   return "\033[35;1m[CRITICAL]\033[0m";
        default:                     return "\033[37m[UNKNOWN]\033[0m";
    }
}

#ifdef __cplusplus
}
#endif

#endif // AEGIS_MODEL_H
